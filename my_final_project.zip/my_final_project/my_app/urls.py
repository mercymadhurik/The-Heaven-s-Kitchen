from django.urls import path
from . import views


urlpatterns=[
    path('',views.index,name='index'),
    path('about/',views.about,name='about'),
    path('booking/',views.bookatable_view,name='booking'),
    path('contact/',views.sendamessage_view,name='contact'),
    path('payment/confirm/', views.unified_payment_view, name='unified_payment_view'),
    path('menu/',views.menu,name='menu'),
    path('service/',views.service,name='service'),
    path('signup/',views.signup_view,name='signup'),
    path('team/',views.team,name='team'),
    path('testimonial/',views.testimonial,name='testimonial'),
    path('confirm_booking/', views.confirm_booking, name='confirm_booking'),
    path('success/', views.success, name='success'),
    path('payment/confirm/success/', views.success, name='success'),
    path('payment/confirm/success.html', views.success, name='success'),
   
 
    
   
]