from django.shortcuts import render,redirect
from decimal import Decimal, InvalidOperation
from .models import Signup, Register, Bookatable, Sendamessage, Googlepay, Phonepay, Cardpayment, Cashpayment

def index(request):
    return render(request,'index.html')
def about(request):
    return render(request,'about.html')
def menu(request):
    return render(request,'menu.html')
def service(request):
    return render(request,'service.html')
def team(request):
    return render(request,'team.html')
def testimonial(request):
    return render(request,'testimonial.html')
def confirm_booking(request):
    return render(request, 'confirm_booking.html')
def success(request):
    return render(request, 'success.html')



def signup_view(request):
    if request.method == 'POST':
        if 'name' in request.POST:  # Identifies the Signup form
            Signup.objects.create(
                name=request.POST['name'],
                email=request.POST['email'],
                password=request.POST['password']
            )
        elif 'uname_r' in request.POST:  # Identifies the Register form
            Register.objects.create(
                name=request.POST['name_r'],
                username=request.POST['uname_r'],
                email=request.POST['email_r'],
                password=request.POST['password_r'],
                phone=request.POST['phone_r'],
                dob=request.POST['date_r'],
                gender=request.POST['gender'],
                street=request.POST['street'],
                city=request.POST['city'],
                state=request.POST['state'],
                zip=request.POST['zip'],
                terms_accepted='terms' in request.POST
            )
        return redirect('index')  # Redirect to home after submission

    return render(request, 'signup.html')


def bookatable_view(request):
    if request.method=='POST':
        name_bb=request.POST.get('name_bb')
        email_bb=request.POST.get('email_bb')
        datetime_bb=request.POST.get('datetime_bb')
        people_bb=request.POST.get('people_bb')
        message_bb=request.POST.get('message_bb')
        
        Bookatable.objects.create(
            name_bb=name_bb,
            email_bb=email_bb,
            datetime_bb=datetime_bb,
            people_bb=people_bb,
            message_bb=message_bb
        )
        
        
        return redirect('index')
    return render(request, 'booking.html')
  

def sendamessage_view(request):
    if request.method=='POST':
        name_m=request.POST.get('name_m')
        email_m=request.POST.get('email_m')
        subject_m=request.POST.get('subject_m')
        message_m=request.POST.get('message_m')
        
        
        print("Contact form received:")
        print("Name:", name_m)
        print("Email:", email_m)
        print("Subject:", subject_m)
        print("Message:", message_m)
        
        Sendamessage.objects.create(
            name_m=name_m,
            email_m=email_m,
            subject_m=subject_m,
            message_m=message_m
        )
        
        return redirect('index')
    return render(request, 'contact.html')


def unified_payment_view(request):
    if request.method == 'POST':
        payment_method = request.POST.get('payment_method')

        # Google Pay or PhonePe or Cash
        if payment_method in ['googlepay', 'phonepay', 'cash']:
            try:
                amount = Decimal(request.POST.get('amount'))
            except (InvalidOperation, TypeError):
                return render(request, 'confirm_booking.html', {'error': 'Invalid or missing amount.'})

        try:
            if payment_method == 'googlepay':
                Googlepay.objects.create(
                    upi_id1=request.POST.get('upi_id'),
                    customer_name1=request.POST.get('customer_name'),
                    amount1=amount
                )

            elif payment_method == 'phonepay':
                Phonepay.objects.create(
                    upi_id2=request.POST.get('upi_id'),
                    customer_name2=request.POST.get('customer_name'),
                    amount2=amount
                )

            elif payment_method == 'card':
                Cardpayment.objects.create(
                    name_on_card=request.POST.get('name_on_card'),
                    card_number=request.POST.get('card_number'),
                    expiry=request.POST.get('expiry'),
                    cvv=request.POST.get('cvv')
                )

            elif payment_method == 'cash':
                Cashpayment.objects.create(
                    customer_name3=request.POST.get('customer_name'),
                    amount3=amount
                )
        except Exception as e:
            return render(request, 'confirm_booking.html', {'error': f'Payment processing failed: {e}'})

        return redirect('success')

    return render(request, 'confirm_booking.html')


