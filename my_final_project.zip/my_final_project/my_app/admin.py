from django.contrib import admin
from .models import Signup, Register, Bookatable, Sendamessage, Googlepay, Phonepay, Cardpayment, Cashpayment

admin.site.register(Signup)
admin.site.register(Register)
admin.site.register(Bookatable)
admin.site.register(Sendamessage)
admin.site.register(Googlepay)
admin.site.register(Phonepay)
admin.site.register(Cardpayment)
admin.site.register(Cashpayment)
