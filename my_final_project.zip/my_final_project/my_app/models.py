from django.db import models

PEOPLE_CHOICES = [
        ('1', '1 Person'),
        ('2', '2 People'),
        ('3', '3 People'),
        ('4', 'Family Seating'),
        ('5', 'Couple Seating'),
]
    


class Signup(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Register(models.Model):
    name = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    email = models.EmailField()
    password = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    dob = models.DateField()
    gender = models.CharField(max_length=10)
    street = models.CharField(max_length=255)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    zip = models.CharField(max_length=10)
    terms_accepted = models.BooleanField(default=False)

    def __str__(self):
        return self.username

    
    
class Bookatable(models.Model):
    name_bb = models.CharField(max_length=100)
    email_bb = models.EmailField()
    datetime_bb = models.DateTimeField()  
    people_bb = models.CharField(max_length=20, choices=PEOPLE_CHOICES)
    message_bb=models.TextField(null=True, blank=True)

    def __str__(self):
        return f"Booking for {self.get_people_bb_display()} - name {self.name_bb}"
    
    
    
class Sendamessage(models.Model):
    name_m=models.CharField(max_length=100)
    email_m= models.EmailField()
    subject_m= models.TextField()
    message_m= models.TextField(null=True, blank=True)
    
    def __str__(self):
        return f"name {self.name_m} email {self.email_m} subject{self.subject_m} message {self.message_m}"
    


class Googlepay(models.Model):
    upi_id1 = models.CharField(max_length=100, default="unknown@upi")
    customer_name1 = models.CharField(max_length=100, default="GPay user")
    amount1 = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    def __str__(self):
        return f"{self.customer_name1} - Google Pay"

class Phonepay(models.Model):
    upi_id2 = models.CharField(max_length=100, default="unknown@upi")
    customer_name2 = models.CharField(max_length=100, default="Phonepay user")
    amount2 = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    def __str__(self):
        return f"{self.customer_name2} - PhonePe"

class Cardpayment(models.Model):
    name_on_card = models.CharField(max_length=100, default="cardholder")
    card_number = models.CharField(max_length=16, default="0000000000000000")
    expiry = models.CharField(max_length=10, default="12/30")
    cvv = models.CharField(max_length=4, default="000")

    def __str__(self):
        return f"{self.name_on_card} - Card Payment"

class Cashpayment(models.Model):
    customer_name3 = models.CharField(max_length=100, default="cash customer")
    amount3 = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    def __str__(self):
        return f"{self.customer_name3} - Cash Payment"
